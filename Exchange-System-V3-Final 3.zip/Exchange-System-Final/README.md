# Exchange System V3

Hệ thống quản lý tiền vào, tiền ra, phí và số dư cho nhiều nhóm Telegram, kèm website quản trị tối ưu cho điện thoại.

## Chức năng Telegram

### Nút thao tác trong nhóm

- `➕ Tiền vào`
- `➖ Tiền ra`
- `📄 Giao dịch`
- `📊 Báo cáo`
- `📋 Chốt`

### Lệnh chung

```text
/start
/menu
/id
/cancel
```

### Lệnh Super Admin

```text
/setupgroup Tên nhóm|Phí
/groups
/addstaff UserID|Tên nhân viên
/addstaffall UserID|Tên nhân viên
/grant UserID|Mã nhóm
/revoke UserID|Mã nhóm
/revokeall UserID
/setfee Mã nhóm|Phí
/renamegroup Mã nhóm|Tên mới
/chottong
```

`/addstaffall` tự cấp quyền cho toàn bộ nhóm đang hoạt động. `/revokeall` gỡ toàn bộ quyền nhóm nhưng vẫn giữ tài khoản nhân viên. `/chottong` chỉ hoạt động trong `SUPER_ADMIN_CHAT_ID` và chỉ cho chốt tổng khi tất cả nhóm hoạt động đã chốt.

## Nội dung tiền vào

```text
✅ Đã cộng tiền

Số tiền:
200.000đ

Phí (4%):
8.000đ

Còn lại:
2.112.000đ
```

## Nội dung tiền ra

```text
✅ Đã trừ tiền

Số tiền:
500.000đ

Còn lại:
1.612.000đ
```

Số dư được phép âm.

## Chốt ngày

```text
✅ Đã chốt ngày

Tiền vào:
5.000.000đ

Tiền ra:
2.000.000đ

Phí:
200.000đ

Còn lại:
2.800.000đ

Số giao dịch:
8
```

Sau khi chốt, thống kê chưa chốt về 0 nhưng số dư nhóm vẫn giữ nguyên. Các giao dịch đã chốt không thể xóa riêng.

## Website Admin điện thoại

Mở:

```text
https://TEN-MIEN-RAILWAY/admin
```

Trình duyệt sẽ hỏi Basic Auth bằng `ADMIN_USERNAME` và `ADMIN_PASSWORD`.

Các trang:

- Trang chủ: tổng tiền vào, tiền ra, phí, số dư, nhóm đã/chưa chốt.
- Nhóm: xem số dư, phí, doanh thu chưa chốt và trạng thái.
- Chi tiết nhóm: đổi tên, đổi phí, xem nhân viên, lịch sử chốt.
- Giao dịch: lọc theo ngày và xóa giao dịch chưa chốt.
- Nhân viên: thêm một lần và tự cấp toàn bộ nhóm đang hoạt động.
- Chốt tổng: xem báo cáo tổng theo ngày.
- Xóa dữ liệu nhóm: xóa giao dịch, lịch sử chốt, báo cáo và đưa số dư về 0; vẫn giữ tên nhóm, Telegram Group ID, phí và quyền nhân viên.

## Biến môi trường Railway

```env
BOT_TOKEN=
DATABASE_URL=
SUPER_ADMIN_USER_ID=
SUPER_ADMIN_CHAT_ID=
ADMIN_USERNAME=admin
ADMIN_PASSWORD=doi-mat-khau-manh
PORT=8080
DATABASE_SSL=true
```

### Lấy ID

1. Nhắn bot `/id` để lấy User ID.
2. Trong nhóm Super Admin gửi `/id` để lấy Chat ID dạng `-100...`.
3. Điền vào Railway Variables.

## Đưa lên Railway

1. Giải nén ZIP.
2. Đưa toàn bộ file và thư mục vào repository GitHub.
3. Commit và Push.
4. Railway tự deploy bằng `npm start`.
5. Chỉ chạy **một replica**.
6. Không chạy thêm `node index.js` trong Railway Console vì có thể gây lỗi Telegram `409 Conflict`.

## Kiểm tra mã nguồn

```bash
npm install
npm run check
npm start
```

## An toàn dữ liệu

- Không gửi `BOT_TOKEN` cho người khác.
- Đổi token ngay nếu đã từng gửi token vào nơi công khai.
- Dùng mật khẩu Admin mạnh.
- Nút xóa giao dịch chỉ xóa giao dịch chưa chốt.
- Nút xóa toàn bộ dữ liệu nhóm không thể hoàn tác.
