"use strict";

document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll("form[data-confirm]").forEach((form) => {
        form.addEventListener("submit", (event) => {
            const message = form.dataset.confirm || "Bạn có chắc chắn?";
            if (!window.confirm(message)) event.preventDefault();
        });
    });

    document.querySelectorAll("form[data-reset-group]").forEach((form) => {
        form.addEventListener("submit", (event) => {
            const groupName = form.dataset.resetGroup;
            const input = form.querySelector('input[name="confirm_name"]');
            if (!input || input.value.trim() !== groupName) {
                event.preventDefault();
                window.alert(`Hãy nhập chính xác tên nhóm: ${groupName}`);
                input?.focus();
                return;
            }

            const confirmed = window.confirm(
                `XÓA TOÀN BỘ DỮ LIỆU NHÓM "${groupName}"?\n\nGiao dịch, lịch sử chốt và số dư sẽ bị xóa. Thao tác này không thể hoàn tác.`
            );
            if (!confirmed) event.preventDefault();
        });
    });

    const searchInput = document.getElementById("groupSearch");
    if (searchInput) {
        searchInput.addEventListener("input", () => {
            const keyword = searchInput.value.trim().toLowerCase();
            document.querySelectorAll("#groupList .group-card").forEach((card) => {
                card.hidden = !card.dataset.search.includes(keyword);
            });
        });
    }
});
