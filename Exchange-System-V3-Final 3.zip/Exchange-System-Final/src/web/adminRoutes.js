const express = require("express");
const pool = require("../config/database");
const { adminAuth, sameOriginForWrites } = require("../middleware/adminAuth");
const {
    getGroupById,
    listGroups,
    updateGroupName,
    updateGroupFee,
    setGroupActive
} = require("../services/groupService");
const {
    listStaff,
    getGroupStaff,
    addStaffAllGroups,
    revokeAllGroups
} = require("../services/staffService");
const {
    listGroupTransactions,
    deleteTransaction,
    resetGroupData
} = require("../services/transactionService");
const { getDashboard, getDailyClosingReport } = require("../services/reportService");
const {
    formatMoney,
    formatPercent,
    formatDateTime,
    todayInVietnam
} = require("../utils/format");

const router = express.Router();

function asyncHandler(handler) {
    return (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);
}

function redirectWith(res, path, type, message) {
    const separator = path.includes("?") ? "&" : "?";
    res.redirect(`${path}${separator}${type}=${encodeURIComponent(message)}`);
}

function validId(value) {
    return /^\d+$/.test(String(value || ""));
}

router.use(adminAuth, sameOriginForWrites);
router.use((req, res, next) => {
    res.locals.formatMoney = formatMoney;
    res.locals.formatPercent = formatPercent;
    res.locals.formatDateTime = formatDateTime;
    res.locals.currentPath = req.path;
    res.locals.successMessage = req.query.success || "";
    res.locals.errorMessage = req.query.error || "";
    res.locals.adminUsername = req.adminUsername;
    next();
});

router.get("/", (_req, res) => res.redirect("/admin/dashboard"));

router.get("/dashboard", asyncHandler(async (_req, res) => {
    const dashboard = await getDashboard();
    res.render("dashboard", {
        pageTitle: "Trang chủ",
        activePage: "dashboard",
        ...dashboard
    });
}));

router.get("/groups", asyncHandler(async (_req, res) => {
    const groups = await listGroups();
    res.render("groups", {
        pageTitle: "Danh sách nhóm",
        activePage: "groups",
        groups
    });
}));

router.get("/groups/:id", asyncHandler(async (req, res) => {
    if (!validId(req.params.id)) return res.status(404).render("error", {
        pageTitle: "Không tìm thấy",
        statusCode: 404,
        message: "Mã nhóm không hợp lệ."
    });

    const [group, staff, closingsResult] = await Promise.all([
        getGroupById(req.params.id),
        getGroupStaff(req.params.id),
        pool.query(
            `SELECT * FROM daily_closings WHERE group_id = $1 ORDER BY created_at DESC LIMIT 10`,
            [req.params.id]
        )
    ]);

    if (!group) return res.status(404).render("error", {
        pageTitle: "Không tìm thấy",
        statusCode: 404,
        message: "Không tìm thấy nhóm."
    });

    res.render("group-detail", {
        pageTitle: group.group_name,
        activePage: "groups",
        group,
        staff,
        closings: closingsResult.rows
    });
}));

router.post("/groups/:id/name", asyncHandler(async (req, res) => {
    const groupName = String(req.body.group_name || "").trim();
    if (!validId(req.params.id) || groupName.length < 2 || groupName.length > 100) {
        return redirectWith(res, `/admin/groups/${req.params.id}`, "error", "Tên nhóm không hợp lệ.");
    }
    const group = await updateGroupName(req.params.id, groupName, req.adminUsername);
    if (!group) return redirectWith(res, "/admin/groups", "error", "Không tìm thấy nhóm.");
    redirectWith(res, `/admin/groups/${req.params.id}`, "success", "Đã đổi tên nhóm.");
}));

router.post("/groups/:id/fee", asyncHandler(async (req, res) => {
    const fee = Number(String(req.body.fee_percent || "").replace(",", "."));
    if (!validId(req.params.id) || !Number.isFinite(fee) || fee < 0 || fee > 100) {
        return redirectWith(res, `/admin/groups/${req.params.id}`, "error", "Phí phải từ 0 đến 100.");
    }
    const group = await updateGroupFee(req.params.id, fee, req.adminUsername);
    if (!group) return redirectWith(res, "/admin/groups", "error", "Không tìm thấy nhóm.");
    redirectWith(res, `/admin/groups/${req.params.id}`, "success", "Đã cập nhật phí nhóm.");
}));

router.post("/groups/:id/status", asyncHandler(async (req, res) => {
    const active = String(req.body.active) === "true";
    const group = await setGroupActive(req.params.id, active, req.adminUsername);
    if (!group) return redirectWith(res, "/admin/groups", "error", "Không tìm thấy nhóm.");
    redirectWith(
        res,
        `/admin/groups/${req.params.id}`,
        "success",
        active ? "Đã kích hoạt nhóm." : "Đã ngừng hoạt động nhóm."
    );
}));

router.get("/groups/:id/transactions", asyncHandler(async (req, res) => {
    const group = await getGroupById(req.params.id);
    if (!group) return res.status(404).render("error", {
        pageTitle: "Không tìm thấy",
        statusCode: 404,
        message: "Không tìm thấy nhóm."
    });

    const date = /^\d{4}-\d{2}-\d{2}$/.test(String(req.query.date || ""))
        ? String(req.query.date)
        : todayInVietnam();
    const transactions = await listGroupTransactions(group.id, { date, limit: 300 });

    res.render("transactions", {
        pageTitle: "Giao dịch",
        activePage: "transactions",
        group,
        date,
        transactions
    });
}));

router.post("/transactions/:id/delete", async (req, res) => {
    const groupId = String(req.body.group_id || "");
    const date = String(req.body.date || todayInVietnam());
    const returnPath = `/admin/groups/${groupId}/transactions?date=${encodeURIComponent(date)}`;

    try {
        if (!validId(req.params.id) || !validId(groupId)) {
            return redirectWith(res, returnPath, "error", "Giao dịch không hợp lệ.");
        }
        await deleteTransaction(req.params.id, groupId, req.adminUsername);
        return redirectWith(res, returnPath, "success", "Đã xóa giao dịch và tính lại số liệu nhóm.");
    } catch (error) {
        console.error("DELETE TRANSACTION ERROR:", error);
        return redirectWith(res, returnPath, "error", error.publicMessage || "Không thể xóa giao dịch.");
    }
});

router.post("/groups/:id/reset-data", async (req, res) => {
    try {
        const result = await resetGroupData(req.params.id, req.body.confirm_name, req.adminUsername);
        return redirectWith(
            res,
            `/admin/groups/${req.params.id}`,
            "success",
            `Đã xóa ${result.deletedTransactions} giao dịch và ${result.deletedClosings} lần chốt. Số dư đã về 0đ.`
        );
    } catch (error) {
        console.error("RESET GROUP ERROR:", error);
        return redirectWith(
            res,
            `/admin/groups/${req.params.id}`,
            "error",
            error.publicMessage || "Không thể xóa dữ liệu nhóm."
        );
    }
});

router.get("/staff", asyncHandler(async (_req, res) => {
    const staff = await listStaff();
    res.render("staff", {
        pageTitle: "Nhân viên",
        activePage: "staff",
        staff
    });
}));

router.post("/staff/add-all", async (req, res) => {
    const rawUserId = String(req.body.telegram_user_id || "").trim();
    const rawName = String(req.body.display_name || "").trim();
    if (!/^\d+$/.test(rawUserId) || rawName.length < 2) {
        return redirectWith(res, "/admin/staff", "error", "User ID hoặc tên nhân viên không hợp lệ.");
    }

    try {
        const result = await addStaffAllGroups(rawUserId, rawName, req.adminUsername);
        return redirectWith(
            res,
            "/admin/staff",
            "success",
            `Đã lưu nhân viên và cấp mới ${result.grantedCount} nhóm đang hoạt động.`
        );
    } catch (error) {
        console.error("ADD STAFF ALL ERROR:", error);
        return redirectWith(res, "/admin/staff", "error", "Không thể thêm nhân viên.");
    }
});

router.post("/staff/revoke-all", async (req, res) => {
    const rawUserId = String(req.body.telegram_user_id || "").trim();
    if (!/^\d+$/.test(rawUserId)) {
        return redirectWith(res, "/admin/staff", "error", "User ID không hợp lệ.");
    }

    try {
        const result = await revokeAllGroups(rawUserId, req.adminUsername);
        if (!result) return redirectWith(res, "/admin/staff", "error", "Không tìm thấy nhân viên.");
        return redirectWith(
            res,
            "/admin/staff",
            "success",
            `Đã gỡ ${result.removedCount} quyền nhóm của ${result.user.display_name}.`
        );
    } catch (error) {
        console.error("REVOKE STAFF ALL ERROR:", error);
        return redirectWith(res, "/admin/staff", "error", "Không thể gỡ quyền nhân viên.");
    }
});

router.get("/closings", asyncHandler(async (req, res) => {
    const date = /^\d{4}-\d{2}-\d{2}$/.test(String(req.query.date || ""))
        ? String(req.query.date)
        : todayInVietnam();
    const report = await getDailyClosingReport(date);
    res.render("closings", {
        pageTitle: "Chốt tổng",
        activePage: "closings",
        ...report
    });
}));

router.get("/settings", (_req, res) => {
    res.render("settings", {
        pageTitle: "Cài đặt",
        activePage: "settings",
        config: {
            botToken: Boolean(process.env.BOT_TOKEN),
            databaseUrl: Boolean(process.env.DATABASE_URL),
            superAdminUser: Boolean(process.env.SUPER_ADMIN_USER_ID),
            superAdminChat: Boolean(process.env.SUPER_ADMIN_CHAT_ID),
            databaseSsl: String(process.env.DATABASE_SSL || "true")
        }
    });
});

module.exports = router;
