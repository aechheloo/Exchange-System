const pool = require("./config/database");
const {
    formatMoney,
    formatPercent,
    parseMoney,
    displayName,
    todayInVietnam
} = require("./utils/format");
const {
    isSuperAdminUser,
    ensureSuperAdminUser,
    canOperateGroup
} = require("./services/authService");
const {
    getGroupByTelegramId,
    listGroups,
    setupGroup,
    updateGroupName,
    updateGroupFee
} = require("./services/groupService");
const {
    addStaff,
    addStaffAllGroups,
    revokeAllGroups,
    grantOne,
    revokeOne
} = require("./services/staffService");
const {
    addMoney,
    subtractMoney,
    closeDay,
    getTodayTransactions
} = require("./services/transactionService");
const { getDailyClosingReport } = require("./services/reportService");

const MENU = {
    reply_markup: {
        resize_keyboard: true,
        is_persistent: true,
        keyboard: [
            ["➕ Tiền vào", "➖ Tiền ra"],
            ["📄 Giao dịch", "📊 Báo cáo"],
            ["📋 Chốt"]
        ]
    }
};

function registerBot(bot) {
    const states = new Map();

    function stateKey(msg) {
        return `${msg.chat.id}:${msg.from.id}`;
    }

    async function notifySuperAdmin(text, sourceChatId) {
        const target = process.env.SUPER_ADMIN_CHAT_ID;
        if (!target || String(target) === String(sourceChatId)) return;

        try {
            await bot.sendMessage(target, text);
        } catch (error) {
            console.error("SUPER ADMIN NOTIFY ERROR:", error.message);
        }
    }

    async function requireRegisteredGroup(msg) {
        if (!["group", "supergroup"].includes(msg.chat.type)) {
            await bot.sendMessage(msg.chat.id, "❌ Chức năng này chỉ dùng trong nhóm Telegram.");
            return null;
        }

        const group = await getGroupByTelegramId(msg.chat.id);
        if (!group) {
            await bot.sendMessage(
                msg.chat.id,
`❌ Nhóm này chưa được cài đặt.

Super Admin gửi:
/setupgroup Tên nhóm|6`
            );
            return null;
        }
        if (!group.active) {
            await bot.sendMessage(msg.chat.id, "❌ Nhóm này đang ngừng hoạt động.");
            return null;
        }
        return group;
    }

    async function requirePermission(msg, group) {
        const allowed = await canOperateGroup(msg.from.id, group.id);
        if (!allowed) {
            await bot.sendMessage(msg.chat.id, "❌ Bạn không có quyền thao tác trong nhóm này.");
        }
        return allowed;
    }

    function requireSuperAdmin(msg) {
        if (isSuperAdminUser(msg.from.id)) return true;
        bot.sendMessage(msg.chat.id, "❌ Bạn không có quyền sử dụng chức năng này.");
        return false;
    }

    bot.onText(/^\/start(?:@\w+)?$/, async (msg) => {
        await ensureSuperAdminUser(msg.from);
        const text =
`✅ Exchange System đang hoạt động.

Lệnh chung:
/id — Xem Chat ID và User ID
/menu — Hiện các nút thao tác
/cancel — Hủy thao tác đang nhập

Super Admin:
/setupgroup Tên nhóm|Phí
/groups
/addstaff UserID|Tên nhân viên
/addstaffall UserID|Tên nhân viên
/grant UserID|Mã nhóm
/revoke UserID|Mã nhóm
/revokeall UserID
/setfee Mã nhóm|Phí
/renamegroup Mã nhóm|Tên mới
/chottong`;
        await bot.sendMessage(msg.chat.id, text, MENU);
    });

    bot.onText(/^\/menu(?:@\w+)?$/, async (msg) => {
        await bot.sendMessage(msg.chat.id, "Chọn chức năng:", MENU);
    });

    bot.onText(/^\/id(?:@\w+)?$/, async (msg) => {
        await bot.sendMessage(
            msg.chat.id,
`📌 THÔNG TIN ID

Chat ID:
${msg.chat.id}

User ID:
${msg.from.id}`
        );
    });

    bot.onText(/^\/cancel(?:@\w+)?$/, async (msg) => {
        states.delete(stateKey(msg));
        await bot.sendMessage(msg.chat.id, "✅ Đã hủy thao tác.", MENU);
    });

    bot.onText(/^\/setupgroup(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
        if (!requireSuperAdmin(msg)) return;
        if (!["group", "supergroup"].includes(msg.chat.type)) {
            return bot.sendMessage(msg.chat.id, "❌ Hãy gửi lệnh này ngay trong nhóm cần quản lý.");
        }

        const input = (match[1] || "").trim();
        const [rawName, rawFee] = input.split("|").map((part) => part?.trim());
        if (!rawName || rawFee === undefined) {
            return bot.sendMessage(
                msg.chat.id,
`Cách dùng:
/setupgroup Tên nhóm|6

Ví dụ:
/setupgroup Hà Nội VIP|6`
            );
        }

        const fee = Number(rawFee.replace(",", "."));
        if (!Number.isFinite(fee) || fee < 0 || fee > 100) {
            return bot.sendMessage(msg.chat.id, "❌ Phí phải là số từ 0 đến 100.");
        }

        const group = await setupGroup({
            telegramGroupId: msg.chat.id,
            groupName: rawName,
            feePercent: fee,
            actorUserId: msg.from.id
        });

        return bot.sendMessage(
            msg.chat.id,
`✅ ĐÃ CÀI ĐẶT NHÓM

Mã nhóm: ${group.id}
Tên: ${group.group_name}
Phí: ${formatPercent(group.fee_percent)}%
Số dư: ${formatMoney(group.balance)}`,
            MENU
        );
    });

    bot.onText(/^\/groups(?:@\w+)?$/, async (msg) => {
        if (!requireSuperAdmin(msg)) return;
        const groups = await listGroups();
        if (!groups.length) return bot.sendMessage(msg.chat.id, "📭 Chưa có nhóm nào.");

        let text = `📋 DANH SÁCH NHÓM (${groups.length})\n\n`;
        for (const group of groups) {
            const block =
`#${group.id} — ${group.group_name}
Telegram ID: ${group.telegram_group_id}
Phí: ${formatPercent(group.fee_percent)}%
Số dư: ${formatMoney(group.balance)}
Trạng thái: ${group.active ? "Hoạt động" : "Khóa"}

`;
            if ((text + block).length > 3900) {
                await bot.sendMessage(msg.chat.id, text);
                text = "";
            }
            text += block;
        }
        if (text.trim()) await bot.sendMessage(msg.chat.id, text);
    });

    bot.onText(/^\/addstaff(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
        if (!requireSuperAdmin(msg)) return;
        const input = (match[1] || "").trim();
        const [rawUserId, rawName] = input.split("|").map((part) => part?.trim());
        if (!rawUserId || !rawName || !/^\d+$/.test(rawUserId)) {
            return bot.sendMessage(
                msg.chat.id,
`Cách dùng:
/addstaff UserID|Tên nhân viên

Ví dụ:
/addstaff 123456789|Nhân viên A`
            );
        }
        await addStaff(rawUserId, rawName);
        return bot.sendMessage(
            msg.chat.id,
`✅ Đã lưu nhân viên

Tên: ${rawName}
Telegram User ID: ${rawUserId}`
        );
    });

    bot.onText(/^\/addstaffall(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
        if (!requireSuperAdmin(msg)) return;
        const input = (match[1] || "").trim();
        const [rawUserId, rawName] = input.split("|").map((part) => part?.trim());
        if (!rawUserId || !rawName || !/^\d+$/.test(rawUserId)) {
            return bot.sendMessage(
                msg.chat.id,
`❌ Sai cú pháp.

Cách dùng:
/addstaffall UserID|Tên nhân viên

Ví dụ:
/addstaffall 123456789|Nhân viên A`
            );
        }

        const result = await addStaffAllGroups(rawUserId, rawName, String(msg.from.id));
        if (result.activeGroupCount === 0) {
            return bot.sendMessage(
                msg.chat.id,
`⚠️ ĐÃ LƯU NHÂN VIÊN

Tên:
${rawName}

Telegram User ID:
${rawUserId}

Hiện chưa có nhóm nào đang hoạt động nên chưa thể cấp quyền.`
            );
        }

        const title = result.grantedCount > 0 ? "✅ ĐÃ THÊM NHÂN VIÊN" : "✅ ĐÃ CẬP NHẬT NHÂN VIÊN";
        return bot.sendMessage(
            msg.chat.id,
`${title}

Tên:
${rawName}

Telegram User ID:
${rawUserId}

Quyền:
Tất cả nhóm đang hoạt động

Đã cấp mới:
${result.grantedCount} nhóm

Đã có quyền từ trước:
${result.previousCount} nhóm

Tổng quyền hiện tại:
${result.totalPermissionCount} nhóm`
        );
    });

    bot.onText(/^\/grant(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
        if (!requireSuperAdmin(msg)) return;
        const input = (match[1] || "").trim();
        const [rawUserId, rawGroupId] = input.split("|").map((part) => part?.trim());
        if (!/^\d+$/.test(rawUserId || "") || !/^\d+$/.test(rawGroupId || "")) {
            return bot.sendMessage(
                msg.chat.id,
`Cách dùng:
/grant UserID|Mã nhóm

Ví dụ:
/grant 123456789|1`
            );
        }
        const result = await grantOne(rawUserId, rawGroupId);
        if (result.rowCount === 0) {
            return bot.sendMessage(msg.chat.id, "❌ Không tìm thấy nhân viên hoặc nhóm. Hãy dùng /addstaff và /groups trước.");
        }
        return bot.sendMessage(msg.chat.id, `✅ Đã cấp quyền User ${rawUserId} cho nhóm #${rawGroupId}.`);
    });

    bot.onText(/^\/revoke(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
        if (!requireSuperAdmin(msg)) return;
        const input = (match[1] || "").trim();
        const [rawUserId, rawGroupId] = input.split("|").map((part) => part?.trim());
        if (!/^\d+$/.test(rawUserId || "") || !/^\d+$/.test(rawGroupId || "")) {
            return bot.sendMessage(msg.chat.id, "Cách dùng:\n/revoke UserID|Mã nhóm");
        }
        const result = await revokeOne(rawUserId, rawGroupId);
        return bot.sendMessage(msg.chat.id, result.rowCount ? "✅ Đã gỡ quyền." : "ℹ️ Không tìm thấy quyền cần gỡ.");
    });

    bot.onText(/^\/revokeall(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
        if (!requireSuperAdmin(msg)) return;
        const rawUserId = (match[1] || "").trim();
        if (!/^\d+$/.test(rawUserId)) {
            return bot.sendMessage(msg.chat.id, "❌ Sai cú pháp.\n\nCách dùng:\n/revokeall UserID");
        }
        const result = await revokeAllGroups(rawUserId, String(msg.from.id));
        if (!result) return bot.sendMessage(msg.chat.id, "❌ Không tìm thấy nhân viên.");
        return bot.sendMessage(
            msg.chat.id,
`✅ ĐÃ GỠ TOÀN BỘ QUYỀN

Nhân viên:
${result.user.display_name}

Telegram User ID:
${rawUserId}

Đã gỡ quyền khỏi:
${result.removedCount} nhóm

Tài khoản nhân viên vẫn được lưu trong hệ thống.`
        );
    });

    bot.onText(/^\/setfee(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
        if (!requireSuperAdmin(msg)) return;
        const input = (match[1] || "").trim();
        const [rawGroupId, rawFee] = input.split("|").map((part) => part?.trim());
        const fee = Number((rawFee || "").replace(",", "."));
        if (!/^\d+$/.test(rawGroupId || "") || !Number.isFinite(fee) || fee < 0 || fee > 100) {
            return bot.sendMessage(msg.chat.id, "Cách dùng:\n/setfee Mã nhóm|Phí\n\nVí dụ:\n/setfee 1|7");
        }
        const group = await updateGroupFee(Number(rawGroupId), fee, msg.from.id);
        return bot.sendMessage(
            msg.chat.id,
            group ? `✅ Đã đổi phí ${group.group_name} thành ${formatPercent(group.fee_percent)}%.` : "❌ Không tìm thấy nhóm."
        );
    });

    bot.onText(/^\/renamegroup(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
        if (!requireSuperAdmin(msg)) return;
        const input = (match[1] || "").trim();
        const separatorIndex = input.indexOf("|");
        if (separatorIndex < 1) {
            return bot.sendMessage(msg.chat.id, "Cách dùng:\n/renamegroup Mã nhóm|Tên mới\n\nVí dụ:\n/renamegroup 1|Hà Nội VIP");
        }
        const rawGroupId = input.slice(0, separatorIndex).trim();
        const groupName = input.slice(separatorIndex + 1).trim();
        if (!/^\d+$/.test(rawGroupId) || groupName.length < 2) {
            return bot.sendMessage(msg.chat.id, "❌ Mã nhóm hoặc tên mới không hợp lệ.");
        }
        const group = await updateGroupName(Number(rawGroupId), groupName, msg.from.id);
        return bot.sendMessage(msg.chat.id, group ? `✅ Đã đổi tên nhóm thành ${group.group_name}.` : "❌ Không tìm thấy nhóm.");
    });

    bot.onText(/^\/chottong(?:@\w+)?$/, async (msg) => {
        if (!requireSuperAdmin(msg)) return;
        const configuredChat = process.env.SUPER_ADMIN_CHAT_ID;
        if (configuredChat && String(configuredChat) !== String(msg.chat.id)) {
            return bot.sendMessage(msg.chat.id, "❌ Lệnh /chottong chỉ dùng trong nhóm Super Admin đã cấu hình.");
        }

        const report = await getDailyClosingReport(todayInVietnam());
        if (report.unclosedGroups.length > 0) {
            const names = report.unclosedGroups.map((group) => `• ${group.group_name}`).join("\n");
            return bot.sendMessage(
                msg.chat.id,
`⚠️ CHƯA THỂ CHỐT TỔNG

Còn ${report.unclosedGroups.length} nhóm chưa chốt:

${names}

Vui lòng chốt các nhóm trên trước.`
            );
        }

        const dateText = new Date(`${report.date}T12:00:00+07:00`).toLocaleDateString("vi-VN");
        const summaryText =
`✅ ĐÃ CHỐT TỔNG NGÀY

Ngày:
${dateText}

Tổng tiền vào:
${formatMoney(report.summary.total_in)}

Tổng tiền ra:
${formatMoney(report.summary.total_out)}

Tổng phí:
${formatMoney(report.summary.total_fee)}

Còn lại:
${formatMoney(report.summary.remaining)}

Tổng giao dịch:
${report.summary.transaction_count}

Số nhóm đã chốt:
${report.summary.closed_group_count} nhóm`;
        await bot.sendMessage(msg.chat.id, summaryText);

        if (report.details.length) {
            let detailsText = "📋 CHI TIẾT CÁC NHÓM\n\n";
            for (const [index, item] of report.details.entries()) {
                const block =
`${index + 1}. ${item.group_name}
Vào: ${formatMoney(item.total_in)}
Ra: ${formatMoney(item.total_out)}
Phí: ${formatMoney(item.total_fee)}
Còn lại: ${formatMoney(item.remaining)}

`;
                if ((detailsText + block).length > 3900) {
                    await bot.sendMessage(msg.chat.id, detailsText);
                    detailsText = "";
                }
                detailsText += block;
            }
            if (detailsText.trim()) await bot.sendMessage(msg.chat.id, detailsText);
        }
    });

    bot.on("message", async (msg) => {
        if (!msg.text || !msg.from || msg.text.startsWith("/")) return;
        const text = msg.text.trim();
        const key = stateKey(msg);

        if (text === "➕ Tiền vào") {
            const group = await requireRegisteredGroup(msg);
            if (!group || !(await requirePermission(msg, group))) return;
            states.set(key, { action: "IN", groupId: group.id });
            return bot.sendMessage(msg.chat.id, "💰 Nhập số tiền:");
        }

        if (text === "➖ Tiền ra") {
            const group = await requireRegisteredGroup(msg);
            if (!group || !(await requirePermission(msg, group))) return;
            states.set(key, { action: "OUT", groupId: group.id });
            return bot.sendMessage(msg.chat.id, "💸 Nhập số tiền:");
        }

        if (text === "📊 Báo cáo") {
            const group = await requireRegisteredGroup(msg);
            if (!group || !(await requirePermission(msg, group))) return;
            const current = await getGroupByTelegramId(msg.chat.id);
            return bot.sendMessage(
                msg.chat.id,
`📊 BÁO CÁO HÔM NAY

Nhóm: ${current.group_name}

Tiền vào:
${formatMoney(current.daily_in)}

Tiền ra:
${formatMoney(current.daily_out)}

Tổng phí:
${formatMoney(current.daily_fee)}

Còn lại:
${formatMoney(current.balance)}

Số giao dịch:
${current.daily_tx_count}`
            );
        }

        if (text === "📄 Giao dịch") {
            const group = await requireRegisteredGroup(msg);
            if (!group || !(await requirePermission(msg, group))) return;
            const transactions = await getTodayTransactions(group.id, 10);
            if (!transactions.length) return bot.sendMessage(msg.chat.id, "📭 Hôm nay chưa có giao dịch.");
            const lines = transactions.map((tx) => {
                const time = new Date(tx.created_at).toLocaleTimeString("vi-VN", {
                    hour: "2-digit",
                    minute: "2-digit",
                    timeZone: "Asia/Ho_Chi_Minh"
                });
                const sign = tx.type === "IN" ? "➕" : "➖";
                return `${time} ${sign} ${formatMoney(tx.amount)} — Còn ${formatMoney(tx.balance_after)}`;
            });
            return bot.sendMessage(msg.chat.id, `📄 GIAO DỊCH HÔM NAY\n\n${lines.join("\n")}`);
        }

        if (text === "📋 Chốt") {
            const group = await requireRegisteredGroup(msg);
            if (!group || !(await requirePermission(msg, group))) return;
            const result = await closeDay({ groupId: group.id, telegramUserId: msg.from.id });
            const closing = result.closing;
            const response =
`✅ Đã chốt ngày

Tiền vào:
${formatMoney(closing.total_in)}

Tiền ra:
${formatMoney(closing.total_out)}

Phí:
${formatMoney(closing.total_fee)}

Còn lại:
${formatMoney(closing.closing_balance)}

Số giao dịch:
${closing.transaction_count}`;
            await bot.sendMessage(msg.chat.id, response, MENU);
            await notifySuperAdmin(
                `${response}\n\nNhóm:\n${group.group_name}\n\nNgười chốt: ${displayName(msg.from)}`,
                msg.chat.id
            );
            return;
        }

        const state = states.get(key);
        if (!state) return;
        const amount = parseMoney(text);
        if (!amount) return bot.sendMessage(msg.chat.id, "❌ Số tiền không hợp lệ. Ví dụ: 10000000");

        const group = await requireRegisteredGroup(msg);
        if (!group || group.id !== state.groupId) {
            states.delete(key);
            return;
        }
        if (!(await requirePermission(msg, group))) {
            states.delete(key);
            return;
        }

        try {
            if (state.action === "IN") {
                const result = await addMoney({
                    groupId: group.id,
                    amount,
                    telegramUserId: msg.from.id,
                    telegramUsername: msg.from.username || null
                });
                states.delete(key);
                const response =
`✅ Đã cộng tiền

Số tiền:
${formatMoney(result.amount)}

Phí (${formatPercent(result.feePercent)}%):
${formatMoney(result.feeAmount)}

Còn lại:
${formatMoney(result.balance)}`;
                await bot.sendMessage(msg.chat.id, response, MENU);
                await notifySuperAdmin(
`🔔 GIAO DỊCH MỚI

Nhóm:
${group.group_name}

${response}

Người nhập:
${displayName(msg.from)}`,
                    msg.chat.id
                );
                return;
            }

            if (state.action === "OUT") {
                const result = await subtractMoney({
                    groupId: group.id,
                    amount,
                    telegramUserId: msg.from.id,
                    telegramUsername: msg.from.username || null
                });
                states.delete(key);
                const response =
`✅ Đã trừ tiền

Số tiền:
${formatMoney(result.amount)}

Còn lại:
${formatMoney(result.balance)}`;
                await bot.sendMessage(msg.chat.id, response, MENU);
                await notifySuperAdmin(
`🔔 GIAO DỊCH MỚI

Nhóm:
${group.group_name}

${response}

Người nhập:
${displayName(msg.from)}`,
                    msg.chat.id
                );
            }
        } catch (error) {
            console.error("TRANSACTION ERROR:", error);
            await bot.sendMessage(msg.chat.id, "❌ Không thể lưu giao dịch.");
        }
    });

    bot.on("error", (error) => {
        console.error("TELEGRAM BOT ERROR:", error.message);
    });
}

module.exports = registerBot;
