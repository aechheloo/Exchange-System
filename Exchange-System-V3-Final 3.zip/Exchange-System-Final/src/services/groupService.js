const pool = require("../config/database");

async function getGroupByTelegramId(telegramGroupId) {
    const result = await pool.query(
        "SELECT * FROM groups WHERE telegram_group_id = $1 LIMIT 1",
        [telegramGroupId]
    );
    return result.rows[0] || null;
}

async function getGroupById(groupId) {
    const result = await pool.query(
        `
        SELECT g.*,
               COUNT(DISTINCT p.user_id)::int AS staff_count,
               COUNT(DISTINCT t.id)::int AS transaction_count
        FROM groups g
        LEFT JOIN permissions p ON p.group_id = g.id
        LEFT JOIN transactions t ON t.group_id = g.id
        WHERE g.id = $1
        GROUP BY g.id
        `,
        [groupId]
    );
    return result.rows[0] || null;
}

async function listGroups() {
    const result = await pool.query(`
        SELECT g.*,
               COUNT(DISTINCT p.user_id)::int AS staff_count
        FROM groups g
        LEFT JOIN permissions p ON p.group_id = g.id
        GROUP BY g.id
        ORDER BY g.active DESC, g.id ASC
    `);
    return result.rows;
}

async function setupGroup({ telegramGroupId, groupName, feePercent, actorUserId }) {
    const result = await pool.query(
        `
        INSERT INTO groups (
            telegram_group_id,
            group_name,
            fee_percent,
            created_by_telegram_user_id,
            active
        )
        VALUES ($1, $2, $3, $4, TRUE)
        ON CONFLICT (telegram_group_id)
        DO UPDATE SET
            group_name = EXCLUDED.group_name,
            fee_percent = EXCLUDED.fee_percent,
            active = TRUE,
            updated_at = NOW()
        RETURNING *
        `,
        [telegramGroupId, groupName, feePercent, actorUserId]
    );

    await pool.query(
        `INSERT INTO audit_logs(action, entity_type, entity_id, actor, details)
         VALUES ('GROUP_SETUP', 'group', $1, $2, $3::jsonb)`,
        [
            result.rows[0].id,
            String(actorUserId),
            JSON.stringify({ groupName, feePercent, telegramGroupId: String(telegramGroupId) })
        ]
    );

    return result.rows[0];
}

async function updateGroupName(groupId, groupName, actorUserId = "web-admin") {
    const result = await pool.query(
        `
        UPDATE groups
        SET group_name = $2, updated_at = NOW()
        WHERE id = $1
        RETURNING *
        `,
        [groupId, groupName]
    );

    if (result.rows[0]) {
        await pool.query(
            `INSERT INTO audit_logs(action, entity_type, entity_id, actor, details)
             VALUES ('GROUP_RENAME', 'group', $1, $2, $3::jsonb)`,
            [groupId, String(actorUserId), JSON.stringify({ groupName })]
        );
    }

    return result.rows[0] || null;
}

async function updateGroupFee(groupId, feePercent, actorUserId = "web-admin") {
    const result = await pool.query(
        `
        UPDATE groups
        SET fee_percent = $2, updated_at = NOW()
        WHERE id = $1
        RETURNING *
        `,
        [groupId, feePercent]
    );

    if (result.rows[0]) {
        await pool.query(
            `INSERT INTO audit_logs(action, entity_type, entity_id, actor, details)
             VALUES ('GROUP_FEE_UPDATE', 'group', $1, $2, $3::jsonb)`,
            [groupId, String(actorUserId), JSON.stringify({ feePercent })]
        );
    }

    return result.rows[0] || null;
}

async function setGroupActive(groupId, active, actor = "web-admin") {
    const result = await pool.query(
        `UPDATE groups SET active = $2, updated_at = NOW() WHERE id = $1 RETURNING *`,
        [groupId, active]
    );

    if (result.rows[0]) {
        await pool.query(
            `INSERT INTO audit_logs(action, entity_type, entity_id, actor, details)
             VALUES ('GROUP_STATUS_UPDATE', 'group', $1, $2, $3::jsonb)`,
            [groupId, actor, JSON.stringify({ active })]
        );
    }

    return result.rows[0] || null;
}

module.exports = {
    getGroupByTelegramId,
    getGroupById,
    listGroups,
    setupGroup,
    updateGroupName,
    updateGroupFee,
    setGroupActive
};
