const pool = require("../config/database");

function createPublicError(code, message, statusCode = 400) {
    const error = new Error(message);
    error.code = code;
    error.publicMessage = message;
    error.statusCode = statusCode;
    return error;
}

async function addMoney({ groupId, amount, telegramUserId, telegramUsername }) {
    const client = await pool.connect();

    try {
        await client.query("BEGIN");
        const groupResult = await client.query(
            "SELECT * FROM groups WHERE id = $1 AND active = TRUE FOR UPDATE",
            [groupId]
        );
        const group = groupResult.rows[0];
        if (!group) throw createPublicError("GROUP_NOT_FOUND", "Không tìm thấy nhóm đang hoạt động.", 404);

        const feePercent = Number(group.fee_percent || 0);
        const feeAmount = Math.round((amount * feePercent) / 100);
        const netAmount = amount - feeAmount;
        const balanceBefore = Number(group.balance || 0);
        const balanceAfter = balanceBefore + netAmount;

        const txResult = await client.query(
            `
            INSERT INTO transactions (
                group_id, type, amount, fee_percent, fee_amount, net_amount,
                balance_before, balance_after, telegram_user_id, telegram_username
            )
            VALUES ($1, 'IN', $2, $3, $4, $5, $6, $7, $8, $9)
            RETURNING *
            `,
            [
                groupId,
                amount,
                feePercent,
                feeAmount,
                netAmount,
                balanceBefore,
                balanceAfter,
                telegramUserId,
                telegramUsername
            ]
        );

        await client.query(
            `
            UPDATE groups
            SET balance = $2,
                daily_in = daily_in + $3,
                daily_fee = daily_fee + $4,
                daily_tx_count = daily_tx_count + 1,
                updated_at = NOW()
            WHERE id = $1
            `,
            [groupId, balanceAfter, amount, feeAmount]
        );

        await client.query("COMMIT");
        return {
            transaction: txResult.rows[0],
            amount,
            feePercent,
            feeAmount,
            netAmount,
            balance: balanceAfter
        };
    } catch (error) {
        await client.query("ROLLBACK");
        throw error;
    } finally {
        client.release();
    }
}

async function subtractMoney({ groupId, amount, telegramUserId, telegramUsername }) {
    const client = await pool.connect();

    try {
        await client.query("BEGIN");
        const groupResult = await client.query(
            "SELECT * FROM groups WHERE id = $1 AND active = TRUE FOR UPDATE",
            [groupId]
        );
        const group = groupResult.rows[0];
        if (!group) throw createPublicError("GROUP_NOT_FOUND", "Không tìm thấy nhóm đang hoạt động.", 404);

        const balanceBefore = Number(group.balance || 0);
        const balanceAfter = balanceBefore - amount;

        const txResult = await client.query(
            `
            INSERT INTO transactions (
                group_id, type, amount, fee_percent, fee_amount, net_amount,
                balance_before, balance_after, telegram_user_id, telegram_username
            )
            VALUES ($1, 'OUT', $2, 0, 0, $2, $3, $4, $5, $6)
            RETURNING *
            `,
            [groupId, amount, balanceBefore, balanceAfter, telegramUserId, telegramUsername]
        );

        await client.query(
            `
            UPDATE groups
            SET balance = $2,
                daily_out = daily_out + $3,
                daily_tx_count = daily_tx_count + 1,
                updated_at = NOW()
            WHERE id = $1
            `,
            [groupId, balanceAfter, amount]
        );

        await client.query("COMMIT");
        return {
            transaction: txResult.rows[0],
            amount,
            balance: balanceAfter
        };
    } catch (error) {
        await client.query("ROLLBACK");
        throw error;
    } finally {
        client.release();
    }
}

async function getTodayTransactions(groupId, limit = 10) {
    const result = await pool.query(
        `
        SELECT *
        FROM transactions
        WHERE group_id = $1
          AND (created_at AT TIME ZONE 'Asia/Ho_Chi_Minh')::date =
              (NOW() AT TIME ZONE 'Asia/Ho_Chi_Minh')::date
        ORDER BY created_at DESC, id DESC
        LIMIT $2
        `,
        [groupId, limit]
    );
    return result.rows;
}

async function closeDay({ groupId, telegramUserId }) {
    const client = await pool.connect();

    try {
        await client.query("BEGIN");
        const groupResult = await client.query(
            "SELECT * FROM groups WHERE id = $1 AND active = TRUE FOR UPDATE",
            [groupId]
        );
        const group = groupResult.rows[0];
        if (!group) throw createPublicError("GROUP_NOT_FOUND", "Không tìm thấy nhóm đang hoạt động.", 404);

        const totalsResult = await client.query(
            `
            SELECT
                COALESCE(SUM(amount) FILTER (WHERE type = 'IN'), 0) AS total_in,
                COALESCE(SUM(amount) FILTER (WHERE type = 'OUT'), 0) AS total_out,
                COALESCE(SUM(fee_amount), 0) AS total_fee,
                COUNT(*)::int AS transaction_count
            FROM transactions
            WHERE group_id = $1
              AND closing_id IS NULL
              AND ($2::timestamptz IS NULL OR created_at > $2::timestamptz)
            `,
            [groupId, group.last_closed_at]
        );
        const totals = totalsResult.rows[0];

        const closingResult = await client.query(
            `
            INSERT INTO daily_closings (
                group_id, closing_date, total_in, total_out, total_fee,
                closing_balance, transaction_count, created_by_telegram_user_id
            )
            VALUES (
                $1,
                (NOW() AT TIME ZONE 'Asia/Ho_Chi_Minh')::date,
                $2, $3, $4, $5, $6, $7
            )
            RETURNING *
            `,
            [
                groupId,
                totals.total_in,
                totals.total_out,
                totals.total_fee,
                group.balance,
                totals.transaction_count,
                telegramUserId
            ]
        );
        const closing = closingResult.rows[0];

        await client.query(
            `UPDATE transactions
             SET closing_id = $2
             WHERE group_id = $1
               AND closing_id IS NULL
               AND ($3::timestamptz IS NULL OR created_at > $3::timestamptz)`,
            [groupId, closing.id, group.last_closed_at]
        );

        await client.query(
            `
            UPDATE groups
            SET daily_in = 0,
                daily_out = 0,
                daily_fee = 0,
                daily_tx_count = 0,
                last_closed_at = NOW(),
                last_closed_date = (NOW() AT TIME ZONE 'Asia/Ho_Chi_Minh')::date,
                updated_at = NOW()
            WHERE id = $1
            `,
            [groupId]
        );

        await client.query("COMMIT");
        return { closing };
    } catch (error) {
        await client.query("ROLLBACK");
        throw error;
    } finally {
        client.release();
    }
}

async function listGroupTransactions(groupId, options = {}) {
    const values = [groupId];
    const conditions = ["t.group_id = $1"];

    if (options.date) {
        values.push(options.date);
        conditions.push(`(t.created_at AT TIME ZONE 'Asia/Ho_Chi_Minh')::date = $${values.length}::date`);
    }

    const limit = Math.min(Math.max(Number(options.limit || 100), 1), 500);
    values.push(limit);

    const result = await pool.query(
        `
        SELECT t.*,
               CASE
                   WHEN t.closing_id IS NOT NULL THEN TRUE
                   WHEN g.last_closed_at IS NOT NULL AND t.created_at <= g.last_closed_at THEN TRUE
                   ELSE FALSE
               END AS is_closed
        FROM transactions t
        JOIN groups g ON g.id = t.group_id
        WHERE ${conditions.join(" AND ")}
        ORDER BY t.created_at DESC, t.id DESC
        LIMIT $${values.length}
        `,
        values
    );
    return result.rows;
}

async function recalculateGroup(client, groupId) {
    await client.query(
        `
        WITH ordered AS (
            SELECT id,
                   CASE WHEN type = 'IN' THEN net_amount ELSE -amount END AS delta,
                   SUM(CASE WHEN type = 'IN' THEN net_amount ELSE -amount END)
                       OVER (ORDER BY created_at ASC, id ASC) AS running_balance
            FROM transactions
            WHERE group_id = $1
        )
        UPDATE transactions t
        SET balance_before = o.running_balance - o.delta,
            balance_after = o.running_balance
        FROM ordered o
        WHERE t.id = o.id
        `,
        [groupId]
    );

    const balanceResult = await client.query(
        `
        SELECT COALESCE(SUM(CASE WHEN type = 'IN' THEN net_amount ELSE -amount END), 0) AS balance
        FROM transactions
        WHERE group_id = $1
        `,
        [groupId]
    );

    const dailyResult = await client.query(
        `
        SELECT
            COALESCE(SUM(amount) FILTER (WHERE type = 'IN'), 0) AS daily_in,
            COALESCE(SUM(amount) FILTER (WHERE type = 'OUT'), 0) AS daily_out,
            COALESCE(SUM(fee_amount), 0) AS daily_fee,
            COUNT(*)::int AS daily_tx_count
        FROM transactions t
        JOIN groups g ON g.id = t.group_id
        WHERE t.group_id = $1
          AND t.closing_id IS NULL
          AND (g.last_closed_at IS NULL OR t.created_at > g.last_closed_at)
        `,
        [groupId]
    );

    const daily = dailyResult.rows[0];
    await client.query(
        `
        UPDATE groups
        SET balance = $2,
            daily_in = $3,
            daily_out = $4,
            daily_fee = $5,
            daily_tx_count = $6,
            updated_at = NOW()
        WHERE id = $1
        `,
        [
            groupId,
            balanceResult.rows[0].balance,
            daily.daily_in,
            daily.daily_out,
            daily.daily_fee,
            daily.daily_tx_count
        ]
    );
}

async function deleteTransaction(transactionId, groupId, actor = "web-admin") {
    const client = await pool.connect();

    try {
        await client.query("BEGIN");
        await client.query("SELECT id FROM groups WHERE id = $1 FOR UPDATE", [groupId]);
        const txResult = await client.query(
            `SELECT t.*, g.last_closed_at
             FROM transactions t
             JOIN groups g ON g.id = t.group_id
             WHERE t.id = $1 AND t.group_id = $2
             FOR UPDATE OF t`,
            [transactionId, groupId]
        );
        const transaction = txResult.rows[0];

        if (!transaction) throw createPublicError("TRANSACTION_NOT_FOUND", "Không tìm thấy giao dịch.", 404);
        if (
            transaction.closing_id ||
            (transaction.last_closed_at && new Date(transaction.created_at) <= new Date(transaction.last_closed_at))
        ) {
            throw createPublicError(
                "TRANSACTION_CLOSED",
                "Giao dịch đã chốt nên không thể xóa riêng. Hãy dùng Xóa dữ liệu nhóm nếu thực sự cần làm sạch toàn bộ.",
                409
            );
        }

        await client.query("DELETE FROM transactions WHERE id = $1", [transactionId]);
        await recalculateGroup(client, groupId);
        await client.query(
            `INSERT INTO audit_logs(action, entity_type, entity_id, actor, details)
             VALUES ('TRANSACTION_DELETE', 'transaction', $1, $2, $3::jsonb)`,
            [transactionId, actor, JSON.stringify(transaction)]
        );

        await client.query("COMMIT");
        return transaction;
    } catch (error) {
        await client.query("ROLLBACK");
        throw error;
    } finally {
        client.release();
    }
}

async function resetGroupData(groupId, confirmName, actor = "web-admin") {
    const client = await pool.connect();

    try {
        await client.query("BEGIN");
        const groupResult = await client.query(
            "SELECT * FROM groups WHERE id = $1 FOR UPDATE",
            [groupId]
        );
        const group = groupResult.rows[0];
        if (!group) throw createPublicError("GROUP_NOT_FOUND", "Không tìm thấy nhóm.", 404);
        if (String(confirmName || "").trim() !== group.group_name) {
            throw createPublicError("CONFIRM_NAME_INVALID", "Tên nhóm xác nhận chưa đúng.", 400);
        }

        const txCountResult = await client.query(
            "SELECT COUNT(*)::int AS total FROM transactions WHERE group_id = $1",
            [groupId]
        );
        const closingCountResult = await client.query(
            "SELECT COUNT(*)::int AS total FROM daily_closings WHERE group_id = $1",
            [groupId]
        );

        await client.query("DELETE FROM transactions WHERE group_id = $1", [groupId]);
        await client.query("DELETE FROM daily_closings WHERE group_id = $1", [groupId]);
        await client.query(
            `
            UPDATE groups
            SET balance = 0,
                daily_in = 0,
                daily_out = 0,
                daily_fee = 0,
                daily_tx_count = 0,
                last_closed_at = NULL,
                last_closed_date = NULL,
                updated_at = NOW()
            WHERE id = $1
            `,
            [groupId]
        );

        const details = {
            groupName: group.group_name,
            deletedTransactions: txCountResult.rows[0].total,
            deletedClosings: closingCountResult.rows[0].total
        };
        await client.query(
            `INSERT INTO audit_logs(action, entity_type, entity_id, actor, details)
             VALUES ('GROUP_DATA_RESET', 'group', $1, $2, $3::jsonb)`,
            [groupId, actor, JSON.stringify(details)]
        );

        await client.query("COMMIT");
        return { group, ...details };
    } catch (error) {
        await client.query("ROLLBACK");
        throw error;
    } finally {
        client.release();
    }
}

module.exports = {
    addMoney,
    subtractMoney,
    closeDay,
    getTodayTransactions,
    listGroupTransactions,
    deleteTransaction,
    resetGroupData
};
