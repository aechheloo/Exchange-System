const pool = require("../config/database");
const { displayName } = require("../utils/format");

function isSuperAdminUser(telegramUserId) {
    const configured = process.env.SUPER_ADMIN_USER_ID;
    return Boolean(configured) && String(configured) === String(telegramUserId);
}

async function ensureSuperAdminUser(from) {
    if (!from || !isSuperAdminUser(from.id)) return null;

    const result = await pool.query(
        `
        INSERT INTO users (
            telegram_user_id,
            display_name,
            telegram_username,
            role,
            active
        )
        VALUES ($1, $2, $3, 'super_admin', TRUE)
        ON CONFLICT (telegram_user_id)
        DO UPDATE SET
            display_name = EXCLUDED.display_name,
            telegram_username = EXCLUDED.telegram_username,
            role = 'super_admin',
            active = TRUE,
            updated_at = NOW()
        RETURNING *
        `,
        [from.id, displayName(from), from.username || null]
    );

    return result.rows[0];
}

async function canOperateGroup(telegramUserId, groupId) {
    if (isSuperAdminUser(telegramUserId)) return true;

    const result = await pool.query(
        `
        SELECT 1
        FROM users u
        JOIN permissions p ON p.user_id = u.id
        JOIN groups g ON g.id = p.group_id
        WHERE u.telegram_user_id = $1
          AND p.group_id = $2
          AND u.active = TRUE
          AND g.active = TRUE
        LIMIT 1
        `,
        [telegramUserId, groupId]
    );

    return result.rowCount > 0;
}

module.exports = {
    isSuperAdminUser,
    ensureSuperAdminUser,
    canOperateGroup
};
