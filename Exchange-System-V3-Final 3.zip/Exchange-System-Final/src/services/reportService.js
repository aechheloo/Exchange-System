const pool = require("../config/database");
const { todayInVietnam } = require("../utils/format");

async function getDashboard() {
    const summaryResult = await pool.query(`
        SELECT
            COALESCE(SUM(daily_in), 0) AS total_in,
            COALESCE(SUM(daily_out), 0) AS total_out,
            COALESCE(SUM(daily_fee), 0) AS total_fee,
            COALESCE(SUM(balance), 0) AS total_balance,
            COALESCE(SUM(daily_tx_count), 0)::int AS transaction_count,
            COUNT(*) FILTER (WHERE active = TRUE)::int AS active_group_count,
            COUNT(*)::int AS group_count,
            COUNT(*) FILTER (
                WHERE active = TRUE
                  AND last_closed_date = (NOW() AT TIME ZONE 'Asia/Ho_Chi_Minh')::date
                  AND daily_tx_count = 0
            )::int AS closed_group_count
        FROM groups
    `);

    const recentResult = await pool.query(`
        SELECT t.*, g.group_name
        FROM transactions t
        JOIN groups g ON g.id = t.group_id
        ORDER BY t.created_at DESC, t.id DESC
        LIMIT 8
    `);

    const summary = summaryResult.rows[0];
    summary.unclosed_group_count = Math.max(
        Number(summary.active_group_count || 0) - Number(summary.closed_group_count || 0),
        0
    );

    return { summary, recentTransactions: recentResult.rows };
}

async function getDailyClosingReport(date = todayInVietnam()) {
    const detailsResult = await pool.query(
        `
        SELECT g.id AS group_id,
               g.group_name,
               COALESCE(SUM(c.total_in), 0) AS total_in,
               COALESCE(SUM(c.total_out), 0) AS total_out,
               COALESCE(SUM(c.total_fee), 0) AS total_fee,
               COALESCE(SUM(c.total_in - c.total_out - c.total_fee), 0) AS remaining,
               COALESCE(SUM(c.transaction_count), 0)::int AS transaction_count,
               MAX(c.created_at) AS closed_at
        FROM daily_closings c
        JOIN groups g ON g.id = c.group_id
        WHERE c.closing_date = $1::date
          AND g.active = TRUE
        GROUP BY g.id, g.group_name
        ORDER BY g.id ASC
        `,
        [date]
    );

    const unclosedResult = await pool.query(
        `
        SELECT id, group_name
        FROM groups
        WHERE active = TRUE
          AND (
              last_closed_date IS DISTINCT FROM $1::date
              OR daily_tx_count > 0
          )
        ORDER BY id ASC
        `,
        [date]
    );

    const groupCountResult = await pool.query(
        "SELECT COUNT(*)::int AS total FROM groups WHERE active = TRUE"
    );

    const details = detailsResult.rows;
    const summary = details.reduce(
        (acc, item) => {
            acc.total_in += Number(item.total_in || 0);
            acc.total_out += Number(item.total_out || 0);
            acc.total_fee += Number(item.total_fee || 0);
            acc.remaining += Number(item.remaining || 0);
            acc.transaction_count += Number(item.transaction_count || 0);
            return acc;
        },
        { total_in: 0, total_out: 0, total_fee: 0, remaining: 0, transaction_count: 0 }
    );

    summary.active_group_count = groupCountResult.rows[0].total;
    summary.closed_group_count = details.length;
    summary.unclosed_group_count = unclosedResult.rows.length;

    return { date, summary, details, unclosedGroups: unclosedResult.rows };
}

module.exports = {
    getDashboard,
    getDailyClosingReport
};
