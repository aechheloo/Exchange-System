const pool = require("../config/database");

async function addStaff(rawUserId, rawName) {
    const result = await pool.query(
        `
        INSERT INTO users (telegram_user_id, display_name, role, active)
        VALUES ($1, $2, 'staff', TRUE)
        ON CONFLICT (telegram_user_id)
        DO UPDATE SET
            display_name = EXCLUDED.display_name,
            role = CASE WHEN users.role = 'super_admin' THEN users.role ELSE 'staff' END,
            active = TRUE,
            updated_at = NOW()
        RETURNING *
        `,
        [rawUserId, rawName]
    );
    return result.rows[0];
}

async function addStaffAllGroups(rawUserId, rawName, actor = "telegram-super-admin") {
    const client = await pool.connect();

    try {
        await client.query("BEGIN");

        const userResult = await client.query(
            `
            INSERT INTO users (telegram_user_id, display_name, role, active)
            VALUES ($1, $2, 'staff', TRUE)
            ON CONFLICT (telegram_user_id)
            DO UPDATE SET
                display_name = EXCLUDED.display_name,
                role = CASE WHEN users.role = 'super_admin' THEN users.role ELSE 'staff' END,
                active = TRUE,
                updated_at = NOW()
            RETURNING *
            `,
            [rawUserId, rawName]
        );

        const user = userResult.rows[0];
        const activeCountResult = await client.query(
            "SELECT COUNT(*)::int AS total FROM groups WHERE active = TRUE"
        );
        const activeGroupCount = activeCountResult.rows[0].total;

        const beforeResult = await client.query(
            `
            SELECT COUNT(*)::int AS total
            FROM permissions p
            JOIN groups g ON g.id = p.group_id
            WHERE p.user_id = $1 AND g.active = TRUE
            `,
            [user.id]
        );
        const previousCount = beforeResult.rows[0].total;

        const insertResult = await client.query(
            `
            INSERT INTO permissions (user_id, group_id)
            SELECT $1, g.id
            FROM groups g
            WHERE g.active = TRUE
            ON CONFLICT (user_id, group_id) DO NOTHING
            RETURNING id
            `,
            [user.id]
        );

        const totalResult = await client.query(
            "SELECT COUNT(*)::int AS total FROM permissions WHERE user_id = $1",
            [user.id]
        );

        await client.query(
            `INSERT INTO audit_logs(action, entity_type, entity_id, actor, details)
             VALUES ('STAFF_GRANT_ALL', 'user', $1, $2, $3::jsonb)`,
            [
                user.id,
                actor,
                JSON.stringify({ telegramUserId: String(rawUserId), granted: insertResult.rowCount })
            ]
        );

        await client.query("COMMIT");

        return {
            user,
            activeGroupCount,
            grantedCount: insertResult.rowCount,
            previousCount,
            totalPermissionCount: totalResult.rows[0].total
        };
    } catch (error) {
        await client.query("ROLLBACK");
        throw error;
    } finally {
        client.release();
    }
}

async function revokeAllGroups(rawUserId, actor = "telegram-super-admin") {
    const client = await pool.connect();

    try {
        await client.query("BEGIN");
        const userResult = await client.query(
            "SELECT * FROM users WHERE telegram_user_id = $1 LIMIT 1",
            [rawUserId]
        );

        if (!userResult.rows[0]) {
            await client.query("ROLLBACK");
            return null;
        }

        const user = userResult.rows[0];
        const deleteResult = await client.query(
            "DELETE FROM permissions WHERE user_id = $1",
            [user.id]
        );

        await client.query(
            `INSERT INTO audit_logs(action, entity_type, entity_id, actor, details)
             VALUES ('STAFF_REVOKE_ALL', 'user', $1, $2, $3::jsonb)`,
            [user.id, actor, JSON.stringify({ removed: deleteResult.rowCount })]
        );

        await client.query("COMMIT");
        return { user, removedCount: deleteResult.rowCount };
    } catch (error) {
        await client.query("ROLLBACK");
        throw error;
    } finally {
        client.release();
    }
}

async function listStaff() {
    const result = await pool.query(`
        SELECT u.*,
               COUNT(p.id)::int AS permission_count
        FROM users u
        LEFT JOIN permissions p ON p.user_id = u.id
        WHERE u.role <> 'super_admin'
        GROUP BY u.id
        ORDER BY u.active DESC, u.display_name ASC
    `);
    return result.rows;
}

async function getGroupStaff(groupId) {
    const result = await pool.query(
        `
        SELECT u.*
        FROM users u
        JOIN permissions p ON p.user_id = u.id
        WHERE p.group_id = $1
        ORDER BY u.display_name ASC
        `,
        [groupId]
    );
    return result.rows;
}

async function grantOne(rawUserId, groupId) {
    return pool.query(
        `
        INSERT INTO permissions (user_id, group_id)
        SELECT u.id, g.id
        FROM users u
        JOIN groups g ON g.id = $2
        WHERE u.telegram_user_id = $1
        ON CONFLICT (user_id, group_id) DO NOTHING
        RETURNING id
        `,
        [rawUserId, groupId]
    );
}

async function revokeOne(rawUserId, groupId) {
    return pool.query(
        `
        DELETE FROM permissions p
        USING users u
        WHERE p.user_id = u.id
          AND u.telegram_user_id = $1
          AND p.group_id = $2
        `,
        [rawUserId, groupId]
    );
}

module.exports = {
    addStaff,
    addStaffAllGroups,
    revokeAllGroups,
    listStaff,
    getGroupStaff,
    grantOne,
    revokeOne
};
