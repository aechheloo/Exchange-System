const pool = require("../config/database");

async function initDatabase() {
    const client = await pool.connect();

    try {
        await client.query("BEGIN");

        await client.query(`
            CREATE TABLE IF NOT EXISTS users (
                id BIGSERIAL PRIMARY KEY,
                telegram_user_id BIGINT UNIQUE NOT NULL,
                display_name TEXT NOT NULL,
                telegram_username TEXT,
                role VARCHAR(30) NOT NULL DEFAULT 'staff',
                active BOOLEAN NOT NULL DEFAULT TRUE,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        `);

        await client.query(`
            CREATE TABLE IF NOT EXISTS groups (
                id BIGSERIAL PRIMARY KEY,
                telegram_group_id BIGINT UNIQUE NOT NULL,
                group_name TEXT NOT NULL,
                fee_percent NUMERIC(6,2) NOT NULL DEFAULT 0,
                balance NUMERIC(20,0) NOT NULL DEFAULT 0,
                daily_in NUMERIC(20,0) NOT NULL DEFAULT 0,
                daily_out NUMERIC(20,0) NOT NULL DEFAULT 0,
                daily_fee NUMERIC(20,0) NOT NULL DEFAULT 0,
                daily_tx_count INTEGER NOT NULL DEFAULT 0,
                active BOOLEAN NOT NULL DEFAULT TRUE,
                last_closed_at TIMESTAMPTZ,
                last_closed_date DATE,
                created_by_telegram_user_id BIGINT,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        `);

        await client.query(`
            CREATE TABLE IF NOT EXISTS permissions (
                id BIGSERIAL PRIMARY KEY,
                user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                group_id BIGINT NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                UNIQUE (user_id, group_id)
            )
        `);

        await client.query(`
            CREATE TABLE IF NOT EXISTS daily_closings (
                id BIGSERIAL PRIMARY KEY,
                group_id BIGINT NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
                closing_date DATE NOT NULL,
                total_in NUMERIC(20,0) NOT NULL DEFAULT 0,
                total_out NUMERIC(20,0) NOT NULL DEFAULT 0,
                total_fee NUMERIC(20,0) NOT NULL DEFAULT 0,
                closing_balance NUMERIC(20,0) NOT NULL DEFAULT 0,
                transaction_count INTEGER NOT NULL DEFAULT 0,
                created_by_telegram_user_id BIGINT,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        `);

        await client.query(`
            CREATE TABLE IF NOT EXISTS transactions (
                id BIGSERIAL PRIMARY KEY,
                group_id BIGINT NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
                type VARCHAR(10) NOT NULL CHECK (type IN ('IN', 'OUT')),
                amount NUMERIC(20,0) NOT NULL CHECK (amount > 0),
                fee_percent NUMERIC(6,2) NOT NULL DEFAULT 0,
                fee_amount NUMERIC(20,0) NOT NULL DEFAULT 0,
                net_amount NUMERIC(20,0) NOT NULL DEFAULT 0,
                balance_before NUMERIC(20,0) NOT NULL DEFAULT 0,
                balance_after NUMERIC(20,0) NOT NULL DEFAULT 0,
                telegram_user_id BIGINT,
                telegram_username TEXT,
                closing_id BIGINT REFERENCES daily_closings(id) ON DELETE SET NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        `);

        await client.query(`
            CREATE TABLE IF NOT EXISTS audit_logs (
                id BIGSERIAL PRIMARY KEY,
                action TEXT NOT NULL,
                entity_type TEXT NOT NULL,
                entity_id BIGINT,
                actor TEXT,
                details JSONB NOT NULL DEFAULT '{}'::jsonb,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        `);

        const alters = [
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS telegram_username TEXT",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS role VARCHAR(30) NOT NULL DEFAULT 'staff'",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS active BOOLEAN NOT NULL DEFAULT TRUE",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
            "ALTER TABLE groups ADD COLUMN IF NOT EXISTS fee_percent NUMERIC(6,2) NOT NULL DEFAULT 0",
            "ALTER TABLE groups ADD COLUMN IF NOT EXISTS balance NUMERIC(20,0) NOT NULL DEFAULT 0",
            "ALTER TABLE groups ADD COLUMN IF NOT EXISTS daily_in NUMERIC(20,0) NOT NULL DEFAULT 0",
            "ALTER TABLE groups ADD COLUMN IF NOT EXISTS daily_out NUMERIC(20,0) NOT NULL DEFAULT 0",
            "ALTER TABLE groups ADD COLUMN IF NOT EXISTS daily_fee NUMERIC(20,0) NOT NULL DEFAULT 0",
            "ALTER TABLE groups ADD COLUMN IF NOT EXISTS daily_tx_count INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE groups ADD COLUMN IF NOT EXISTS active BOOLEAN NOT NULL DEFAULT TRUE",
            "ALTER TABLE groups ADD COLUMN IF NOT EXISTS last_closed_at TIMESTAMPTZ",
            "ALTER TABLE groups ADD COLUMN IF NOT EXISTS last_closed_date DATE",
            "ALTER TABLE groups ADD COLUMN IF NOT EXISTS created_by_telegram_user_id BIGINT",
            "ALTER TABLE groups ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
            "ALTER TABLE groups ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
            "ALTER TABLE daily_closings ADD COLUMN IF NOT EXISTS closing_date DATE",
            "ALTER TABLE daily_closings ADD COLUMN IF NOT EXISTS total_in NUMERIC(20,0) NOT NULL DEFAULT 0",
            "ALTER TABLE daily_closings ADD COLUMN IF NOT EXISTS total_out NUMERIC(20,0) NOT NULL DEFAULT 0",
            "ALTER TABLE daily_closings ADD COLUMN IF NOT EXISTS total_fee NUMERIC(20,0) NOT NULL DEFAULT 0",
            "ALTER TABLE daily_closings ADD COLUMN IF NOT EXISTS closing_balance NUMERIC(20,0) NOT NULL DEFAULT 0",
            "ALTER TABLE daily_closings ADD COLUMN IF NOT EXISTS transaction_count INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE daily_closings ADD COLUMN IF NOT EXISTS created_by_telegram_user_id BIGINT",
            "ALTER TABLE daily_closings ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
            "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS fee_percent NUMERIC(6,2) NOT NULL DEFAULT 0",
            "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS fee_amount NUMERIC(20,0) NOT NULL DEFAULT 0",
            "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS net_amount NUMERIC(20,0) NOT NULL DEFAULT 0",
            "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS balance_before NUMERIC(20,0) NOT NULL DEFAULT 0",
            "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS balance_after NUMERIC(20,0) NOT NULL DEFAULT 0",
            "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS telegram_user_id BIGINT",
            "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS telegram_username TEXT",
            "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
            "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS closing_id BIGINT REFERENCES daily_closings(id) ON DELETE SET NULL"
        ];

        for (const sql of alters) await client.query(sql);

        await client.query(`
            UPDATE daily_closings
            SET closing_date = (created_at AT TIME ZONE 'Asia/Ho_Chi_Minh')::date
            WHERE closing_date IS NULL
        `);

        await client.query(`
            UPDATE groups g
            SET last_closed_at = latest.created_at,
                last_closed_date = latest.closing_date
            FROM (
                SELECT DISTINCT ON (group_id)
                       group_id, created_at, closing_date
                FROM daily_closings
                ORDER BY group_id, created_at DESC, id DESC
            ) latest
            WHERE g.id = latest.group_id
              AND g.last_closed_at IS NULL
        `);

        await client.query(`
            UPDATE transactions
            SET net_amount = CASE
                WHEN type = 'IN' THEN GREATEST(amount - fee_amount, 0)
                ELSE amount
            END
            WHERE net_amount = 0
        `);

        await client.query("CREATE INDEX IF NOT EXISTS idx_transactions_group_created ON transactions(group_id, created_at DESC)");
        await client.query("CREATE INDEX IF NOT EXISTS idx_transactions_closing ON transactions(closing_id)");
        await client.query("CREATE INDEX IF NOT EXISTS idx_closings_date_group ON daily_closings(closing_date, group_id)");
        await client.query("CREATE INDEX IF NOT EXISTS idx_permissions_group ON permissions(group_id)");
        await client.query("CREATE INDEX IF NOT EXISTS idx_users_telegram ON users(telegram_user_id)");

        await client.query("COMMIT");
        console.log("DATABASE TABLES: READY");
    } catch (error) {
        await client.query("ROLLBACK");
        throw error;
    } finally {
        client.release();
    }
}

module.exports = initDatabase;
