function toNumber(value) {
    const number = Number(value || 0);
    return Number.isFinite(number) ? number : 0;
}

function formatMoney(value) {
    return `${Math.trunc(toNumber(value)).toLocaleString("vi-VN")}đ`;
}

function formatPercent(value) {
    return toNumber(value).toLocaleString("vi-VN", {
        maximumFractionDigits: 2
    });
}

function parseMoney(value) {
    const normalized = String(value || "")
        .trim()
        .replace(/[.\s,_đ₫]/gi, "");

    if (!/^\d+$/.test(normalized)) return null;

    const amount = Number(normalized);
    if (!Number.isSafeInteger(amount) || amount <= 0) return null;
    return amount;
}

function displayName(user) {
    if (!user) return "Không rõ";
    const fullName = [user.first_name, user.last_name].filter(Boolean).join(" ").trim();
    return fullName || user.username || String(user.id || "Không rõ");
}

function formatDateTime(value) {
    if (!value) return "—";
    return new Date(value).toLocaleString("vi-VN", {
        timeZone: "Asia/Ho_Chi_Minh",
        hour: "2-digit",
        minute: "2-digit",
        day: "2-digit",
        month: "2-digit",
        year: "numeric"
    });
}

function todayInVietnam() {
    const parts = new Intl.DateTimeFormat("en-CA", {
        timeZone: "Asia/Ho_Chi_Minh",
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
    }).formatToParts(new Date());

    const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
    return `${values.year}-${values.month}-${values.day}`;
}

module.exports = {
    formatMoney,
    formatPercent,
    parseMoney,
    displayName,
    formatDateTime,
    todayInVietnam,
    toNumber
};
