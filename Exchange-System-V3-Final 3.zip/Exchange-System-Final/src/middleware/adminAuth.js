const crypto = require("crypto");

function safeEqual(left, right) {
    const a = Buffer.from(String(left || ""));
    const b = Buffer.from(String(right || ""));
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
}

function adminAuth(req, res, next) {
    const header = req.headers.authorization || "";
    const [scheme, encoded] = header.split(" ");

    if (scheme !== "Basic" || !encoded) {
        res.set("WWW-Authenticate", 'Basic realm="Exchange System Admin", charset="UTF-8"');
        return res.status(401).send("Cần đăng nhập quản trị.");
    }

    let decoded;
    try {
        decoded = Buffer.from(encoded, "base64").toString("utf8");
    } catch (_error) {
        decoded = "";
    }

    const separator = decoded.indexOf(":");
    const username = separator >= 0 ? decoded.slice(0, separator) : "";
    const password = separator >= 0 ? decoded.slice(separator + 1) : "";

    if (
        !safeEqual(username, process.env.ADMIN_USERNAME) ||
        !safeEqual(password, process.env.ADMIN_PASSWORD)
    ) {
        res.set("WWW-Authenticate", 'Basic realm="Exchange System Admin", charset="UTF-8"');
        return res.status(401).send("Sai tài khoản hoặc mật khẩu.");
    }

    req.adminUsername = username;
    next();
}

function sameOriginForWrites(req, res, next) {
    if (req.method === "GET" || req.method === "HEAD" || req.method === "OPTIONS") {
        return next();
    }

    const origin = req.get("origin");
    if (!origin) return next();

    try {
        const originHost = new URL(origin).host;
        if (originHost !== req.get("host")) {
            return res.status(403).send("Yêu cầu không hợp lệ.");
        }
    } catch (_error) {
        return res.status(403).send("Yêu cầu không hợp lệ.");
    }

    next();
}

module.exports = { adminAuth, sameOriginForWrites };
